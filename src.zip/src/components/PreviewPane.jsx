import { useEffect } from "react"
import { runCode, languageMap } from "../api/runCode"

function PreviewPane({files,runCode:triggerRun,setConsoleLogs}){

useEffect(()=>{

async function execute(){

const file = files.find(f =>
["py","cpp","c","java","js","javascript"].includes(f.language)
)

if(!file) return

let lang

if(file.language==="py") lang="python"
if(file.language==="cpp") lang="cpp"
if(file.language==="c") lang="c"
if(file.language==="java") lang="java"
if(file.language==="js" || file.language==="javascript") lang="javascript"

try{

const result = await runCode(
languageMap[lang],
file.content
)

let output = ""

if(result.stdout){
output = result.stdout
}

if(result.stderr){
output = "❌ " + result.stderr
}

if(result.compile_output){
output = result.compile_output
}

if(result.message){
output = result.message
}

setConsoleLogs([output])

}catch(err){

setConsoleLogs(["Execution error"])

}

}

execute()

},[triggerRun])

return null

}

export default PreviewPane
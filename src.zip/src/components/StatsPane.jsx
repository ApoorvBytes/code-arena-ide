function StatsPane({stats}){

return(

<div style={{
height:"120px",
borderTop:"1px solid #333",
padding:"10px"
}}>

<div>Execution Time: {stats.time} ms</div>
<div>Lines: {stats.lines}</div>
<div>Characters: {stats.chars}</div>

</div>

)

}

export default StatsPane
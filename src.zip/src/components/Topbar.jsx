import JSZip from "jszip"
import { saveAs } from "file-saver"

function Topbar({files,activeFile,setActiveFile,setFiles,setRunCode}){

function createFile(){

const name = prompt("Enter file name")

if(!name) return

const newFile = {
id: Date.now(),
name,
language:name.split(".").pop(),
content:""
}

setFiles([...files,newFile])
setActiveFile(newFile.id)

}

function closeFile(id){

const updated = files.filter(f => f.id !== id)

setFiles(updated)

if(activeFile === id && updated.length>0){
setActiveFile(updated[0].id)
}

}

function renameFile(){

const current = files.find(f=>f.id===activeFile)

const newName = prompt("Rename file",current.name)

if(!newName) return

setFiles(files.map(f =>
f.id===activeFile
? {...f,name:newName,language:newName.split(".").pop()}
: f
))

}

function runProject(){

setRunCode(prev=>!prev)

}

async function downloadProject(){

const zip = new JSZip()

files.forEach(file=>{
zip.file(file.name,file.content)
})

const content = await zip.generateAsync({type:"blob"})

saveAs(content,"code-arena-project.zip")

}

return(

<header className="topbar">

<h2>CODE // ARENA</h2>

<div className="tabs">

{files.map(file => (

<div key={file.id} style={{display:"flex",alignItems:"center"}}>

<button
onClick={()=>setActiveFile(file.id)}
style={{
background: activeFile===file.id ? "#333" : "transparent",
color:"white",
border:"none",
padding:"6px 10px"
}}
>
{file.name}
</button>

<span
onClick={()=>closeFile(file.id)}
style={{cursor:"pointer",color:"red"}}
>
×
</span>

</div>

))}

<button onClick={createFile}>+ File</button>

<button onClick={renameFile}>Rename</button>

<button onClick={runProject}>Run</button>

<button onClick={downloadProject}>Download</button>

</div>

</header>

)

}

export default Topbar
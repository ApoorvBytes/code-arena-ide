import { useEffect } from "react"
import Editor from "@monaco-editor/react"

function EditorPane({ files, activeFile, setFiles, setStats }) {

const file = files.find(f => f.id === activeFile)

/* Prevent crash if file gets deleted */
if (!file) return null

function updateCode(value = "") {

setFiles(files.map(f =>
f.id === activeFile
? { ...f, content: value }
: f
))

const lines = value.split("\n").length
const chars = value.length

setStats(prev => ({
...prev,
lines,
chars
}))

}

useEffect(() => {

function handleKeys(e) {

/* CTRL + S */
if (e.ctrlKey && e.key === "s") {
e.preventDefault()
alert("File Saved (simulation)")
}

/* CTRL + ENTER → Run project trigger */
if (e.ctrlKey && e.key === "Enter") {
alert("Run shortcut coming next upgrade 🚀")
}

}

window.addEventListener("keydown", handleKeys)

return () => window.removeEventListener("keydown", handleKeys)

}, [])

function getLanguage(ext) {

if (ext === "html") return "html"
if (ext === "css") return "css"
if (ext === "js" || ext === "javascript") return "javascript"
if (ext === "py") return "python"
if (ext === "cpp") return "cpp"
if (ext === "c") return "c"
if (ext === "java") return "java"

return "plaintext"

}

return (

<div style={{
flex:1,
display:"flex",
flexDirection:"column",
height:"100%"
}}>

<div style={{
padding:"10px",
borderBottom:"1px solid #333"
}}>
{file.name}
</div>

<div style={{flex:1}}>

<Editor
height="100%"
theme="vs-dark"
language={getLanguage(file.language)}
value={file.content || ""}
onChange={updateCode}
options={{
minimap:{enabled:false},
fontSize:14,
automaticLayout:true,
scrollBeyondLastLine:false
}}
/>

</div>

</div>

)

}

export default EditorPane
function ConsolePane({logs}){

return(

<div style={{
height:"120px",
borderTop:"1px solid #333",
padding:"10px",
overflowY:"auto"
}}>

{logs.length===0 && "Console ready..."}

{logs.map((log,i)=>(
<div key={i}>{log}</div>
))}

</div>

)

}

export default ConsolePane
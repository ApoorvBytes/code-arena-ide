import Explorer from "./Explorer"
import EditorPane from "./EditorPane"
import PreviewPane from "./PreviewPane"
import ConsolePane from "./ConsolePane"
import StatsPane from "./StatsPane"

import { PanelGroup, Panel, PanelResizeHandle } from "react-resizable-panels"

function Workspace({
files,
activeFile,
setFiles,
runCode,
consoleLogs,
setConsoleLogs,
stats,
setStats,
setActiveFile
}){

return(

<div style={{display:"flex",flex:1}}>

<Explorer
files={files}
activeFile={activeFile}
setActiveFile={setActiveFile}
setFiles={setFiles}
/>

<PanelGroup direction="horizontal" style={{flex:1}}>

<Panel defaultSize={50} minSize={30}>

<div className="editor-side">

<EditorPane
files={files}
activeFile={activeFile}
setFiles={setFiles}
setStats={setStats}
/>

<ConsolePane logs={consoleLogs}/>

</div>

</Panel>

<PanelResizeHandle style={{
width:"4px",
background:"#333",
cursor:"col-resize"
}}/>

<Panel defaultSize={50} minSize={30}>

<div className="preview-side">

<PreviewPane
files={files}
runCode={runCode}
setConsoleLogs={setConsoleLogs}
setStats={setStats}
/>

<StatsPane stats={stats}/>

</div>

</Panel>

</PanelGroup>

</div>

)

}

export default Workspace
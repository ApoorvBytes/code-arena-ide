import { useState } from "react"
import Topbar from "./components/Topbar"
import Workspace from "./components/Workspace"
import StatusBar from "./components/StatusBar"
import "./style.css"

function App(){

const [files,setFiles] = useState([
{
id:1,
name:"index.html",
language:"html",
content:"<h1>Hello Arena</h1>"
},
{
id:2,
name:"style.css",
language:"css",
content:"body{background:black;color:white;}"
},
{
id:3,
name:"main.js",
language:"javascript",
content:"console.log('Hello Developer')"
}
])

const [activeFile,setActiveFile] = useState(1)
const [runCode,setRunCode] = useState(false)
const [consoleLogs,setConsoleLogs] = useState([])

const [stats,setStats] = useState({
time:0,
lines:0,
chars:0
})

return(

<div className="shell">

<Topbar
files={files}
activeFile={activeFile}
setActiveFile={setActiveFile}
setFiles={setFiles}
setRunCode={setRunCode}
/>

<Workspace
files={files}
activeFile={activeFile}
setFiles={setFiles}
runCode={runCode}
consoleLogs={consoleLogs}
setConsoleLogs={setConsoleLogs}
stats={stats}
setStats={setStats}
/>

<StatusBar/>

</div>

)

}

export default App